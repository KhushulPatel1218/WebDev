<?php

var_dump($_SERVER['QUERY_STRING']);